package com.example.ems.service;

import com.example.ems.model.Employee;
import com.example.ems.repository.EmployeeRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    private final EmployeeRepository repo;

    public EmployeeService(EmployeeRepository repo) {
        this.repo = repo;
    }

    public List<Employee> getEmployees() {
        return repo.getAllEmployees();
    }

    public void addEmployee(Employee e) {
        repo.addEmployee(e);
    }

    public void deleteEmployee(int id) {
        repo.deleteEmployee(id);
    }
}