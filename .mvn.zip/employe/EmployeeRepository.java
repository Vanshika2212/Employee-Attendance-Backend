package com.example.ems.repository;

import com.example.ems.model.Employee;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class EmployeeRepository {

    private final JdbcTemplate jdbc;

    public EmployeeRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public List<Employee> getAllEmployees() {
        return jdbc.query("SELECT * FROM employees", (rs, rowNum) -> {
            Employee e = new Employee();
            e.setId(rs.getInt("id"));
            e.setName(rs.getString("name"));
            e.setEmail(rs.getString("email"));
            return e;
        });
    }

    public void addEmployee(Employee e) {
        jdbc.update("INSERT INTO employees(name, email) VALUES(?,?)",
                e.getName(), e.getEmail());
    }

    public void deleteEmployee(int id) {
        jdbc.update("DELETE FROM employees WHERE id=?", id);
    }
}